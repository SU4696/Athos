﻿namespace Atos_Part1.model
{
    public class aplicantes
    {
        public string Correo { get; set; }
        public string Contrasena { get; set; }
    }
}
