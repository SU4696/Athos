﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nose1.Controllers
{
    [ApiController]
    [Route("api/apiquestion")]

    public class APIQuestions : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            string cs = @"Server=127.0.0.1;Port=3306;Database=alumnos;Uid=root;password=Kogtma0015*;";
            string pregunta = "Nada";

            using var con = new MySqlConnection(cs);
            con.Open();

            string sql = "SELECT Texto_pregunta FROM preguntas WHERE ID_puesto = 1;";
            using var cmd = new MySqlCommand(sql, con);

            using MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                //Console.WriteLine("{0}",rdr.GetString(0));
                pregunta = rdr.GetString(0);
            }
            return pregunta;
        }
    }
}
