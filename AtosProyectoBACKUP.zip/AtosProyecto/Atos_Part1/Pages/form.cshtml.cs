using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;
using Atos_Part1.model;
using Microsoft.AspNetCore.Http;

namespace Atos_Part1.Pages
{

    public class formModel : PageModel
    {
        private readonly ILogger<formModel> _logger;

        public formModel(ILogger<formModel> logger)
        {
            _logger = logger;
        }
        public string idusuario { get; set; }
        //Datos Personales
        [BindProperty]
        [Required]
        public string nombre { get; set; }
        [BindProperty]
        [Required]
        public string apellidoPaterno { get; set; }
        [BindProperty]
        public string apellidoMaterno { get; set; }
        [BindProperty]
        [Required]
        public string fechaDeNacimiento { get; set; }

        //Informacion de Contacto
        [EmailAddress]
        [BindProperty]
        [Required]
        public string correo { get; set; }
        [Phone]
        [BindProperty]
        [Required]
        public string telefono { get; set; }
        [BindProperty]
        [Required]
        public string direccion { get; set; }

        //Formacion Academica
        [BindProperty]
        [Required]
        public string carrera { get; set; }
        [BindProperty]
        [Required]
        public string universidad { get; set; }
        [BindProperty]
        [DataType(DataType.Date)]
        [Required]
        public string anoinfa { get; set; }
        [BindProperty]
        [DataType(DataType.Date)]
        [Required]
        public string anofinfa { get; set; }
        //Experencia laboral
        [BindProperty]
        [Required]
        public string puesto { get; set; }
        [BindProperty]
        [Required]
        public string descripcion { get; set; }
        [BindProperty]
        [DataType(DataType.Date)]
        [Required]
        public string anoinxp { get; set; }
        [BindProperty]
        [DataType(DataType.Date)]
        [Required]
        public string anooutxp { get; set; }
        [BindProperty]
        [Required]
        public string puestodeseado { get; set; }

        //Idiomas

        //Skills

        public void OnPost()
        {
            idusuario = "26"; //Temporal

            string connectionString = "Server=127.0.0.1;Port=3306;Database=alumnos;Uid=root;password=root;";
            MySqlConnection conexion = new MySqlConnection(connectionString);
            conexion.Open();

            //MySqlCommand cmd = new MySqlCommand();
            MySqlCommand cmd = new MySqlCommand(connectionString, conexion);
            cmd.Connection = conexion;

            using (MySqlCommand cmd1 = new MySqlCommand(connectionString, conexion))
            {
                cmd1.CommandText = "INSERT INTO datospersonales (IDusuario, Nombre, Apellido_paterno, Apellido_materno, Fecha_nacimiento) VALUES (@idusuario, @Nombre, @Apellido_Paterno, @Apellido_Materno, @FechaDeNacimiento); ";
                //cmd.CommandText = "select * from aplicantes where correo=@mail and contrasena=@password;";


                cmd1.Parameters.AddWithValue("@idusuario", idusuario); //Sera el mismo para todas
                cmd1.Parameters.AddWithValue("@Nombre", nombre);
                cmd1.Parameters.AddWithValue("@Apellido_Paterno", apellidoPaterno);
                cmd1.Parameters.AddWithValue("@Apellido_Materno", apellidoMaterno);
                cmd1.Parameters.AddWithValue("@FechaDeNacimiento", fechaDeNacimiento);
                cmd1.Prepare();
                cmd1.ExecuteReader();
            }

            conexion.Close();
            conexion.Open();

            //Informacion de Contacto
            using (MySqlCommand cmd2 = new MySqlCommand(connectionString, conexion))
            {
                cmd2.CommandText = "INSERT INTO informacioncontacto (IDusuario, Telefono, Direccion) VALUES(@idusuario, @Telefono, @Direccion); ";
                //cmd.CommandText = "select * from aplicantes where correo=@mail and contrasena=@password;";

                cmd2.Parameters.AddWithValue("@idusuario", idusuario); //Sera el mismo para todas
                cmd2.Parameters.AddWithValue("@Telefono", telefono);
                cmd2.Parameters.AddWithValue("@Direccion", direccion);

                cmd2.Prepare();
                cmd2.ExecuteReader();
            }

            conexion.Close();
            
            //Formacion Academica (subtabla con IDCarrera)
            conexion.Open();
            //Codigo para Insertar La carrera si no existe previamente en la tabla Carrera (Conectada a formacion Academica).
            using (MySqlCommand cmd3 = new MySqlCommand(connectionString, conexion))
            {
                cmd3.CommandText = "INSERT INTO carrera (Nombre_carrera) VALUES (@Carrera); ";

                cmd3.Parameters.AddWithValue("@idusuario", idusuario); //Sera el mismo para todas
                cmd3.Parameters.AddWithValue("@Carrera", carrera); //De subtabla

                try
                {
                    cmd3.Prepare();
                    cmd3.ExecuteNonQuery();
                }
                catch { }
                //cmd3.Prepare();
                //cmd3.ExecuteReader();
            }
            conexion.Close();

            
            conexion.Open();
            using (MySqlCommand cmd4 = new MySqlCommand(connectionString, conexion))
            {
                //Codigo para buscar la ID_carrera correspoindiente de la anterior e insertarla.
                cmd4.CommandText = "INSERT INTO formacionacademica (IDusuario, ID_carrera, Universidad, Ano_inicio, Ano_fin) " +
                    "VALUES(@idusuario, (SELECT ID_carrera FROM carrera where Nombre_carrera = @Carrera), @Universidad, @Ano_inicio, @Ano_fin);";
                //cmd.CommandText = "select * from aplicantes where correo=@mail and contrasena=@password;";

                cmd4.Parameters.AddWithValue("@idusuario", idusuario); //Sera el mismo para todas
                cmd4.Parameters.AddWithValue("@Carrera", carrera); //De subtabla
                cmd4.Parameters.AddWithValue("@Universidad", universidad);
                cmd4.Parameters.AddWithValue("@Ano_inicio", anoinfa);
                cmd4.Parameters.AddWithValue("@Ano_fin", anofinfa);


                cmd4.Prepare();
                cmd4.ExecuteReader();
            }
            conexion.Close();

            //Experiencia Laboral (Tiene subtabla para ID_Puesto (Es el puesto que quiere aplicar).
            conexion.Open();
            using (MySqlCommand cmd5 = new MySqlCommand(connectionString, conexion))
            {
                //Codigo para buscar el ID_puesto correspoindiente de la anterior e insertarla.
                cmd5.CommandText = "INSERT INTO experiencialaboral (IDusuario, ID_puesto, Titulo_puestoanterior, Descripcion, Ano_inicio, Ano_fin) " +
                    "VALUES(@idusuario, (SELECT ID_puesto FROM puestos where Nombre_puesto = @Puesto_deseado), @ID_puesto, @Descripcion, @Ano_inicioxp, @Ano_finxp);";
                //cmd.CommandText = "select * from aplicantes where correo=@mail and contrasena=@password;";
                cmd5.Parameters.AddWithValue("@idusuario", idusuario); //Sera el mismo para todas
                cmd5.Parameters.AddWithValue("@ID_puesto", puesto);
                cmd5.Parameters.AddWithValue("@Descripcion", descripcion);
                cmd5.Parameters.AddWithValue("@Ano_inicioxp", anoinxp);
                cmd5.Parameters.AddWithValue("@Ano_finxp", anooutxp);
                cmd5.Parameters.AddWithValue("@Puesto_deseado", puestodeseado);



                cmd5.Prepare();
                cmd5.ExecuteReader();
            }
            conexion.Close();
            //To here


            conexion.Dispose(); // Se cierra la conexion

        }
        public void OnGet(string idusuario)
        {
            /*
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("idu")) == false)
            {
                idusuario = HttpContext.Session.GetString("idu");
            } 
            */
        }

        
    }
}
