﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;
using Atos_Part1.model;
using Microsoft.AspNetCore.Http;

namespace Atos_Part1.Pages
{
    public class loginModel : PageModel
    {
        private readonly ILogger<loginModel> _logger;

        public loginModel(ILogger<loginModel> logger)
        {
            _logger = logger;
        }

        int check;
        string result = "0";
        public IList<aplicantes> Listaaplicantes { get; set; }
        [BindProperty]
        [Required]
        [EmailAddress]
        public string mail { get; set; }
        [BindProperty]
        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }
        public void OnPost()
        {
            string connectionString = "Server=127.0.0.1;Port=3306;Database=alumnos;Uid=root;password=root;";
            MySqlConnection conexion = new MySqlConnection(connectionString);
            conexion.Open();

            //MySqlCommand cmd = new MySqlCommand();
            MySqlCommand cmd = new MySqlCommand(connectionString, conexion);
            cmd.Connection = conexion;
            cmd.CommandText = "select * from usuarios where Correo='@mail' and Contrasena=@password;";
            //cmd.CommandText = "select * from aplicantes where correo=@mail and contrasena=@password;";

        
            cmd.Parameters.AddWithValue("@mail", mail);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Prepare();

            aplicantes usr1 = new aplicantes();
            Listaaplicantes = new List<aplicantes>();
            check = 0;
            //check = int.Parse(cmd.ExecuteScalar().ToString());
            int Fiesst = cmd.ExecuteNonQuery();
            System.Diagnostics.Debug.WriteLine(Fiesst);
            //Se comprueba de que el valor si exista (no devuelva null)
            if (Fiesst != 0)
            {
                string idusuario = "1111"; //Acabo de anadir esto como referencia pero no se actualiza
                cmd.CommandText = "select IDusuario from usuarios where Correo=@mail and Contrasena=@password;";
                cmd.Prepare();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                         idusuario = Convert.ToString(reader["IDusuario"]);
                    }
                }
                //System.Diagnostics.Debug.WriteLine(idusuario);
                HttpContext.Session.SetString("idu", idusuario); //Esta Linea marca error
                result = Fiesst.ToString();
                Response.Redirect("form"); //Aqui nos debe llevar a la Main Page

            }
            else
            {
                //El problema es que siempre se va a este else
                result = "0";
                Response.Redirect("mistake");
            }
            
            if (result != "0")
            {
                Response.Redirect("form"); //Aqui nos debe llevar a la Main Page
            }
            else
            {
                Response.Redirect("mistake"); //Aqui nos debe llevar a una pag de error aqui error
            }
            
            conexion.Dispose();
            //Si no es NUll, entonces se encuentra el valor en la DB
            
        }
        

        public void OnGet()
        {
            Listaaplicantes = new List<aplicantes>();
        }
    }
}
