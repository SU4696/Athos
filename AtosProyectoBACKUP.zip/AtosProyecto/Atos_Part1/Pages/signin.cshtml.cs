﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;
using Atos_Part1.model;

namespace Atos_Part1.Pages
{
    public class signinModel : PageModel
    {
        int check;

        public IList<aplicantes> Listaaplicantes { get; set; }
        [BindProperty]
        [Required]
        [EmailAddress]
        public string mail { get; set; }
        [BindProperty]
        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }
        public void OnPost()
        {
            string connectionString = "Server=127.0.0.1;Port=3306;Database=alumnos;Uid=root;password=root;";
            MySqlConnection conexion = new MySqlConnection(connectionString);
            conexion.Open();

            //Desde aqui inicia los comandos SQL
            MySqlCommand cmd = new MySqlCommand(connectionString, conexion);
            cmd.Connection = conexion;
            cmd.CommandText = "INSERT INTO usuarios(Correo, Contrasena) VALUES(@mail,@password)";

            cmd.Parameters.AddWithValue("@mail", mail);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Prepare();

            aplicantes usr1 = new aplicantes();
            Listaaplicantes = new List<aplicantes>();

            try
            {
                cmd.ExecuteReader(); //Se ejecuta la consulta
                Response.Redirect("login");
            }
            catch
            {
                Response.Redirect("mistake");
            }

            conexion.Dispose(); // Se cierra la conexion

        }
        private readonly ILogger<signinModel> _logger;

        public signinModel(ILogger<signinModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            Listaaplicantes = new List<aplicantes>();
            

        }
    }
}
