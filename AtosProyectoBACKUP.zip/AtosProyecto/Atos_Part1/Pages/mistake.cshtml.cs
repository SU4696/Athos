using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Atos_Part1.Pages
{
    public class mistakeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
